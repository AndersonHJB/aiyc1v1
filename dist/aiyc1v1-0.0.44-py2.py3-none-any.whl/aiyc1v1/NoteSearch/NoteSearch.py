class William():
    def __init__(self):
        print("sssss")