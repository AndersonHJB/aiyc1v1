from aiyc1v1.class_coder.simplenlp import Simple_NlP
from aiyc1v1.class_coder.wordcloud import wordcloud
from aiyc1v1.class_coder.GameBase import Creature
from aiyc1v1.class_coder.Q1 import Q1
from aiyc1v1.simplesearch.SimpleSearch import SimpleSearch  # 简易检索器
from aiyc1v1.simplesearch.DataManager import DataManager, DataSearch  # 文件读取 class
# from aiyc1v1.simplesearch.DataManager import DataSearch
from aiyc1v1.GameFunction import GameFunction