from aiyc1v1.simplenlp import Simple_NlP
from aiyc1v1.aiycwordcloud import aiycwordcloud